from tkinter import *
import time
import os
#############################
root = Tk()
root.title("Admin hub")
root.geometry('600x600')
root.resizable(width=False,height=False)
root['bg'] = 'black'
##############################
def cmd1():
    os.startfile('cmd')
def explorer():
    os.startfile('explorer')
############################
def reged():
    os.startfile('regedit')
############################
def gpedi():
    os.startfile('gpedit.msc')
############################
def task():
    os.startfile('taskmgr')
############################
def appda():
    os.startfile('appd.bat')
############################
def tm():
    os.startfile('temp')
############################
def s32():
    os.startfile('sys32.bat')
#############################
title = Label(root, text = 'Привет это тестовый билд Admin hub', font = 'Arian 21', bg= 'lime')
title.pack()
#############################
cmd = Button(root, text = "Открыть cmd", command= cmd1, font= 'Arianl 20', activebackground= 'lime')
cmd.pack()
#############################
expl = Button(root, text= "Открыть explorer", command=explorer, font= 'Arianl 20', activebackground= 'lime')
expl.pack()
#############################
regedit = Button(root, text= "Открыть regedit", command=reged, font= 'Arianl 20', activebackground= 'lime')
regedit.pack()
#############################
gpedit = Button(root, text= "Открыть Gpedit", command=gpedi, font= 'Arianl 20', activebackground= 'lime')
gpedit.pack()
#############################
taskmg = Button(root, text= "Открыть taskmgr", command=task, font= 'Arianl 20', activebackground= 'lime')
taskmg.pack()
#############################
app = Button(root, text= "Открыть appdata", command=appda, font= 'Arianl 20', activebackground= 'lime')
app.pack()

tem = Button(root, text= "Открыть temp", command=tm, font= 'Arianl 20', activebackground= 'lime')
tem.pack()

sys32 = Button(root, text= "Открыть system32", command=s32, font= 'Arianl 20', activebackground= 'lime')
sys32.pack()

root.mainloop()